/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab3;

/**
 *
 * @author User
 */
import java.util.Random;

public class Q4 {

    public static void main(String[] args) {

        Random random = new Random();

        int player1num1 = random.nextInt(1, 7);
        int player1num2 = random.nextInt(6) + 1;

        int player1Score = player1num1 + player1num2;

        int player2num1 = random.nextInt(1, 7);
        int player2num2 = random.nextInt(6) + 1;

        int player2Score = player2num1 + player2num2;

        System.out.println("Player 1");
        System.out.println("First Roll: " + player1num1);
        System.out.println("Second Roll: " + player1num2);
        System.out.println("Total Score: " + player1Score);

        System.out.println("Player 2");
        System.out.println("First Roll: " + player2num1);
        System.out.println("Second Roll: " + player2num2);
        System.out.println("Total Score: " + player2Score);

        if (player1Score > player2Score) {
            System.out.println("Player 1 wins");
        } else if (player2Score > player1Score) {
            System.out.println("Player 2 wins");
        } else {
            System.out.println("Draw");
        }

    }
}
