/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab3;

/**
 *
 * @author User
 */
import java.util.Scanner;

public class Q5 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter a");
        double a = input.nextDouble();

        System.out.println("Enter b");
        double b = input.nextDouble();

        System.out.println("Enter c");
        double c = input.nextDouble();

        System.out.println("Enter d");
        double d = input.nextDouble();

        System.out.println("Enter e");
        double e = input.nextDouble();

        System.out.println("Enter f");
        double f = input.nextDouble();

        double deno = a * d - b * c;

        if (deno == 0) {
            System.out.println("No solution");
        } else {
            double x = (e * d - b * f) / deno;

            double y = (a * f - e * c) / deno;

            System.out.printf("x==%.2f%n", x);
            System.out.printf("y==%.2f%n", y);
        }

    }

}
