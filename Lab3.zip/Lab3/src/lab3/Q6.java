/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab3;

/**
 *
 * @author User
 */
import java.util.Scanner;

public class Q6 {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.println("Enter Radius");
        double radius = input.nextDouble();

        System.out.println("Enter Coordinate X");
        double x = input.nextDouble();

        System.out.println("Enter Coordinate Y");
        double y = input.nextDouble();

        if (radius < 0) {
            System.out.println("Radius cant be 0");
        } else {

            double distanceSquared = x * x + y * y;

            double radiusSquared = radius * radius;

            if (distanceSquared < radiusSquared) {
                System.out.println("Point inside circle");
            } else if (distanceSquared > radiusSquared) {
                System.out.println("Point outside circle");
            } else {
                System.out.println("Point on circle");
            }

        }

        input.close();
    }

}
