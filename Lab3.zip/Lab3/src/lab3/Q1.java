/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab3;

import java.util.Scanner;

public class Q1 {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.println("Please insert two numbers: ");
        int num1 = input.nextInt();
        int num2 = input.nextInt();
        System.out.println("Enter operator ( + - * / %)");
        char operator = input.next().charAt(0);

        switch (operator) {
            case '+':
                System.out.println("Sum is: " + (num1 + num2));
                break;
            case '-':
                System.out.println("Difference is: " + (num1 - num2));
                break;
            case '*':
                System.out.println("Multiplication is: " + (num1 * num2));
                break;
            case '/':
                if (num2 != 0) {
                    System.out.println("Quotient is: " + (num1 / num2));
                } else {
                    System.out.println("Zero is undefined");
                }
                break;
            case '%':
                if (num2 != 0) {
                    System.out.println("Remainder: " + (num1 % num2));
                } else {
                    System.out.println("Zero is undefined");
                }
                break;
            default:
                System.out.println("Invalid");
                break;
        }

        input.close();

    }

}
