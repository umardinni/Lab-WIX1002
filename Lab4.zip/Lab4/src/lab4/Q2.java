/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab4;

/**
 *
 * @author User
 */
import java.util.Scanner;

public class Q2 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter n: ");
        int n = input.nextInt();

        int term = 0;   // current term: 1+2+...+i
        int total = 0;  // sum of all the terms

        for (int i = 1; i <= n; i++) {
            term += i;      // (1+2+...+i) = previous term + i
            total += term;  // add this term to the series
        }

        System.out.println("The sum of the series is " + total);
    }
}
