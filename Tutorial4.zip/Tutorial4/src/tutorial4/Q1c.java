/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tutorial4;

/**
 *
 * @author User
 */
import java.util.Random;

public class Q1c {

    public static void main(String[] args) {
        Random num = new Random();
        int[][] matrix = new int[4][5];

        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                matrix[i][j] = num.nextInt(101);
            }
        }

        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                System.out.print(matrix[i][j] + "\t");

            }
            System.out.println();
        }
    }
}
