/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tutorial4;

/**
 *
 * @author User
 */
public class Q1e {

    public static void main(String[] args) {
        double sum = 0;

         for (int i = 1, j = 25; i <= 25; i++, j--) {
        sum += (double) i / j; 
    }
        System.out.printf("The sum is: %.2f%n" , sum);
    }
}
