/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tutorial4;

/**
 *
 * @author User
 */
public class Q1a {

    public static void main(String[] args) {
        int n = 1, answer=0;
        while ((n*n*n) <= 2000) {
            answer=n;
            n++;
        }
        System.out.println("The largest n cube before 2000 is:" + answer);
    }

}
