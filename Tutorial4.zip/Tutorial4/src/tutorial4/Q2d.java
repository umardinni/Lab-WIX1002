/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tutorial4;

/**
 *
 * @author User
 */
public class Q2d {

    public static void main(String[] args) {
        int i = 1; //TODO int i
        while (i <= 10) {
            if (i == 10) { //TODO impossible condition
                System.out.println("Program End");
            }
            i++; //TODO infinite loop
        }

    }

}
