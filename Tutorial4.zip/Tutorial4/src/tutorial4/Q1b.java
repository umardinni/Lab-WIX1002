/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tutorial4;

/**
 *
 * @author User
 */
public class Q1b {
    public static void main(String[] args) {
        int num=1;
        int squared=0;
        while(num<=12){
            squared=num*num;
            System.out.println("Squared number of " + num + " is: " + squared);
            num++;
        }
    }
    
}
