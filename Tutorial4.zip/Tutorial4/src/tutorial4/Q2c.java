/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tutorial4;

/**
 *
 * @author User
 */
public class Q2c {

    public static void main(String[] args) {
        int x;
        int y;
        for (x = 1, y = 20; x < y ; x++, y -= 2); //TODP x=1vuse semicolon instead of comma
        System.out.println(x + " " + y); //TODO use + instead of &
    }

}
