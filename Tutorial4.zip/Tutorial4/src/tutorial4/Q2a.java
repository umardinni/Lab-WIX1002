/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tutorial4;

/**
 *
 * @author User
 */
public class Q2a {

    public static void main(String[] args) {
        int sum = 0;

        for (int x = 10; x > 0; x++) { //TODO: int before x=10, overflow error cause x>10
            sum += x;
        }
        System.out.println("Sum:" + sum);
    }

}


