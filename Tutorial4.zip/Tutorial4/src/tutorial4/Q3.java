/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tutorial4;

/**
 *
 * @author User
 */
public class Q3 {

    public static void main(String[] args) {

        int f1 = 1;
        int f2 = 1;
        int count = 1;
        int n1 = 1;
        int n2 = 1;

        for (int n = 3; n <= 10; n++) {
            int fn = f1 + f2;
            System.out.print(fn + " ");

            f1 = f2;
            f2 = fn;
        }
        System.out.println();

        while (count <= 10) {
            System.out.print(n1 + " ");
            int next = n1 + n2;
            n1 = n2;
            n2 = next;
            count++;
        }
    }
}
