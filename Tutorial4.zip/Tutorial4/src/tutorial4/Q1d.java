/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tutorial4;

/**
 *
 * @author User
 */
import java.util.Scanner;

public class Q1d {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        int sum=0;

        for (int i=0; i <= n; i++) {
            i += i;
            sum=i;
            
        }
        System.out.println("The sum is: " + sum);
    }
}
